# Chrome POST Stealer Extension aka 'Google Device Protection'
A malicious Chrome extention designed to be sent via social engineering phishing excersises. Rather than delivering begign malware payloads for testing, this is another attack vector that we can monitor. Please see: https://theantisocialengineer.com/exploiting-chrome-attacks-to-educate-staff/ for further information.

v1.2 - Forked repo, updated where POST requests are guided.

v1.3 - Added a pop up window on Chrome that opens and is designed to display a warning page every time data is exfiltrated.
     - Uploaded to Google Extension marketplace to make instalation easier and more believeable to marks.

WARNING - If you install this extention, lets say after having a look at our Github and being curious, it will capture all POST requests in Chrome and ship them to us. If you need that simplyfying, all your passwords and form field after installing this extention are mine. No one should ever willingly install this extension.
